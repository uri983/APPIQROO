*Application Wizard for Bootstrap* by [Andrew Moffat](https://github.com/amoffat), built @ [Panopta](http://www.panopta.com/)

# [Demo & Complete Documentation](http://www.panopta.com/2013/02/06/bootstrap-application-wizard/)

![Screenshot](http://i.imgur.com/e9B2Z.png)

Thanks to:

* [Huzaifa Tapal](https://twitter.com/htapal)
* [Jason Abate](https://github.com/jasonabate)
* [John Zimmerman](https://github.com/johnzimmerman)
* [Shabbir Karimi](https://github.com/shabbirkarimi)
